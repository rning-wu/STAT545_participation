cube = function(x) {
  return(pow(x, 3))
}
