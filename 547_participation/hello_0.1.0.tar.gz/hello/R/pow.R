pow = function(x, p) {
  return(x^p)
}
