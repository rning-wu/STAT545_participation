library(testthat)
library(hello)

test_check("hello")
